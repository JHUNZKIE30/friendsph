import os, sqlite3
from datetime import datetime
from functools import wraps
from flask import Flask, g, request, redirect, url_for, render_template, session, flash, abort
from werkzeug.security import generate_password_hash, check_password_hash

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(APP_DIR, "friendsph.db")
app = Flask(__name__)
app.secret_key = os.environ.get("FRIENDSPH_SECRET", "change-this-secret-before-deployment")

def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db

@app.teardown_appcontext
def close_db(_=None):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()

def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL COLLATE NOCASE,
      email TEXT UNIQUE NOT NULL COLLATE NOCASE,
      password_hash TEXT NOT NULL,
      display_name TEXT NOT NULL,
      bio TEXT NOT NULL DEFAULT '',
      favorite_music TEXT NOT NULL DEFAULT '',
      theme TEXT NOT NULL DEFAULT 'ocean',
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS friendships (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      requester_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      receiver_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','accepted')),
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(requester_id, receiver_id),
      CHECK(requester_id != receiver_id)
    );
    CREATE TABLE IF NOT EXISTS posts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      body TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS comments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      body TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE INDEX IF NOT EXISTS idx_posts_created ON posts(created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_comments_post ON comments(post_id, created_at);
    """)
    conn.commit()
    conn.close()

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("user_id"):
            flash("Mag-login muna para magpatuloy.", "info")
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

@app.context_processor
def common_context():
    current = None
    if session.get("user_id"):
        current = db().execute("SELECT id, username, display_name FROM users WHERE id=?", (session["user_id"],)).fetchone()
    return {"current_user": current}

@app.route("/")
def index():
    if not session.get("user_id"):
        return render_template("landing.html")
    posts = db().execute("""
      SELECT p.*, u.username, u.display_name,
        (SELECT COUNT(*) FROM comments c WHERE c.post_id=p.id) AS comment_count
      FROM posts p JOIN users u ON u.id=p.user_id
      ORDER BY p.id DESC LIMIT 100
    """).fetchall()
    comments = {}
    for p in posts:
        comments[p["id"]] = db().execute("""
          SELECT c.*, u.username, u.display_name FROM comments c
          JOIN users u ON u.id=c.user_id WHERE c.post_id=? ORDER BY c.id ASC
        """, (p["id"],)).fetchall()
    return render_template("feed.html", posts=posts, comments=comments)

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip()
        display_name = request.form.get("display_name", "").strip()
        password = request.form.get("password", "")
        if not (3 <= len(username) <= 24) or not username.replace("_", "").isalnum():
            flash("Username: 3–24 characters; letters, numbers, at underscore lang.", "error")
        elif not email or "@" not in email or len(email) > 160:
            flash("Maglagay ng valid na email address.", "error")
        elif not display_name or len(display_name) > 60:
            flash("Ilagay ang display name (hanggang 60 characters).", "error")
        elif len(password) < 8:
            flash("Dapat hindi bababa sa 8 characters ang password.", "error")
        else:
            try:
                cur = db().execute(
                    "INSERT INTO users(username,email,password_hash,display_name) VALUES(?,?,?,?)",
                    (username, email, generate_password_hash(password), display_name))
                db().commit()
                session.clear()
                session["user_id"] = cur.lastrowid
                flash("Welcome sa FRIENDSPH! Kumpleto na ang account mo.", "success")
                return redirect(url_for("index"))
            except sqlite3.IntegrityError:
                flash("May gumagamit na ng username o email na iyan.", "error")
    return render_template("auth.html", mode="register")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        identifier = request.form.get("identifier", "").strip()
        password = request.form.get("password", "")
        user = db().execute("SELECT * FROM users WHERE username=? OR email=?", (identifier, identifier)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            return redirect(url_for("index"))
        flash("Hindi tugma ang login details.", "error")
    return render_template("auth.html", mode="login")

@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    return redirect(url_for("index"))

@app.route("/u/<username>")
@login_required
def profile(username):
    user = db().execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
    if not user:
        abort(404)
    me = session["user_id"]
    friendship = None
    if me != user["id"]:
        friendship = db().execute("""SELECT * FROM friendships
          WHERE (requester_id=? AND receiver_id=?) OR (requester_id=? AND receiver_id=?)""",
          (me, user["id"], user["id"], me)).fetchone()
    friends = db().execute("""
      SELECT u.id,u.username,u.display_name FROM friendships f
      JOIN users u ON u.id=CASE WHEN f.requester_id=? THEN f.receiver_id ELSE f.requester_id END
      WHERE (f.requester_id=? OR f.receiver_id=?) AND f.status='accepted'
      ORDER BY u.display_name LIMIT 12
    """, (user["id"], user["id"], user["id"])).fetchall()
    posts = db().execute("""SELECT p.*,u.username,u.display_name,
      (SELECT COUNT(*) FROM comments c WHERE c.post_id=p.id) AS comment_count
      FROM posts p JOIN users u ON u.id=p.user_id WHERE p.user_id=? ORDER BY p.id DESC""",
      (user["id"],)).fetchall()
    comments = {p["id"]: db().execute("""SELECT c.*,u.username,u.display_name FROM comments c
      JOIN users u ON u.id=c.user_id WHERE c.post_id=? ORDER BY c.id""", (p["id"],)).fetchall() for p in posts}
    return render_template("profile.html", user=user, friendship=friendship, friends=friends, posts=posts, comments=comments, is_owner=(me == user["id"]))

@app.route("/profile/edit", methods=["GET", "POST"])
@login_required
def edit_profile():
    user = db().execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()
    if request.method == "POST":
        display_name = request.form.get("display_name", "").strip()
        bio = request.form.get("bio", "").strip()[:500]
        favorite_music = request.form.get("favorite_music", "").strip()[:120]
        theme = request.form.get("theme", "ocean")
        if not display_name or len(display_name) > 60:
            flash("Display name ay kailangan at hanggang 60 characters.", "error")
        elif theme not in ("ocean", "sunset", "lavender", "mint"):
            flash("Hindi valid ang theme.", "error")
        else:
            db().execute("UPDATE users SET display_name=?,bio=?,favorite_music=?,theme=? WHERE id=?",
                         (display_name,bio,favorite_music,theme,session["user_id"]))
            db().commit()
            flash("Na-update ang profile mo!", "success")
            return redirect(url_for("profile", username=user["username"]))
    return render_template("edit_profile.html", user=user)

@app.route("/friends")
@login_required
def friends_page():
    uid = session["user_id"]
    incoming = db().execute("""SELECT f.id,f.created_at,u.username,u.display_name FROM friendships f
      JOIN users u ON u.id=f.requester_id WHERE f.receiver_id=? AND f.status='pending' ORDER BY f.id DESC""", (uid,)).fetchall()
    friends = db().execute("""SELECT u.username,u.display_name FROM friendships f
      JOIN users u ON u.id=CASE WHEN f.requester_id=? THEN f.receiver_id ELSE f.requester_id END
      WHERE (f.requester_id=? OR f.receiver_id=?) AND f.status='accepted' ORDER BY u.display_name""",
      (uid,uid,uid)).fetchall()
    sent = db().execute("""SELECT u.username,u.display_name FROM friendships f JOIN users u ON u.id=f.receiver_id
      WHERE f.requester_id=? AND f.status='pending' ORDER BY f.id DESC""", (uid,)).fetchall()
    return render_template("friends.html", incoming=incoming, friends=friends, sent=sent)

@app.route("/people")
@login_required
def people():
    q = request.args.get("q", "").strip()[:60]
    uid = session["user_id"]
    users = db().execute("""SELECT u.id,u.username,u.display_name,u.bio,
      (SELECT status FROM friendships f WHERE
       (f.requester_id=? AND f.receiver_id=u.id) OR (f.requester_id=u.id AND f.receiver_id=?)
      LIMIT 1) AS friend_status,
      (SELECT requester_id FROM friendships f WHERE
       (f.requester_id=? AND f.receiver_id=u.id) OR (f.requester_id=u.id AND f.receiver_id=?)
      LIMIT 1) AS requester_id
      FROM users u WHERE u.id != ? AND (u.username LIKE ? OR u.display_name LIKE ?)
      ORDER BY u.display_name LIMIT 60""",
      (uid,uid,uid,uid,uid,f"%{q}%",f"%{q}%")).fetchall()
    return render_template("people.html", users=users, q=q)

@app.route("/friend/request/<int:user_id>", methods=["POST"])
@login_required
def friend_request(user_id):
    uid = session["user_id"]
    if uid == user_id:
        abort(400)
    exists = db().execute("SELECT id FROM users WHERE id=?", (user_id,)).fetchone()
    if not exists:
        abort(404)
    try:
        db().execute("INSERT INTO friendships(requester_id,receiver_id,status) VALUES(?,?,'pending')", (uid,user_id))
        db().commit()
        flash("Naipadala ang friend request.", "success")
    except sqlite3.IntegrityError:
        flash("May existing friend request o friendship na.", "info")
    return redirect(request.referrer or url_for("people"))

@app.route("/friend/respond/<int:friendship_id>/<action>", methods=["POST"])
@login_required
def friend_respond(friendship_id, action):
    row = db().execute("SELECT * FROM friendships WHERE id=? AND receiver_id=? AND status='pending'",
                       (friendship_id,session["user_id"])).fetchone()
    if not row or action not in ("accept","decline"):
        abort(404)
    if action == "accept":
        db().execute("UPDATE friendships SET status='accepted' WHERE id=?", (friendship_id,))
        flash("Magkaibigan na kayo!", "success")
    else:
        db().execute("DELETE FROM friendships WHERE id=?", (friendship_id,))
        flash("Tinanggihan ang request.", "info")
    db().commit()
    return redirect(url_for("friends_page"))

@app.route("/post", methods=["POST"])
@login_required
def create_post():
    body = request.form.get("body", "").strip()
    if not body or len(body) > 2000:
        flash("Ang post ay dapat 1–2,000 characters.", "error")
    else:
        db().execute("INSERT INTO posts(user_id,body) VALUES(?,?)", (session["user_id"],body))
        db().commit()
    return redirect(request.referrer or url_for("index"))

@app.route("/comment/<int:post_id>", methods=["POST"])
@login_required
def add_comment(post_id):
    body = request.form.get("body", "").strip()
    post = db().execute("SELECT id FROM posts WHERE id=?", (post_id,)).fetchone()
    if not post:
        abort(404)
    if not body or len(body) > 500:
        flash("Ang comment ay dapat 1–500 characters.", "error")
    else:
        db().execute("INSERT INTO comments(post_id,user_id,body) VALUES(?,?,?)",
                     (post_id,session["user_id"],body))
        db().commit()
    return redirect(request.referrer or url_for("index"))

@app.errorhandler(404)
def not_found(_):
    return render_template("error.html", code=404, message="Hindi namin mahanap ang page na iyan."), 404

if __name__ == "__main__":
    init_db()
    app.run(debug=os.environ.get("FLASK_DEBUG") == "1", host="127.0.0.1", port=int(os.environ.get("PORT", 5000)))
