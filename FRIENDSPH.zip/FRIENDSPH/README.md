# FRIENDSPH

A Filipino, Friendster-inspired social networking web app starter built with Python Flask and SQLite.

## Features
- Registration and login (password hashing)
- SQLite database created automatically on first start
- Public activity feed, posts, and comments
- User profiles and editable bio/music/theme
- People search, friend requests, accept/decline, friends list
- Responsive retro-modern blue UI

## Requirements
- Python 3.10 or newer
- Internet connection only to install Flask the first time; the app itself runs locally

## Windows installation
1. Extract `FRIENDSPH.zip` to a folder, for example `C:\FRIENDSPH`.
2. Install Python from https://www.python.org/downloads/ and enable **Add Python to PATH**.
3. Open Command Prompt inside the `FRIENDSPH` folder.
4. Create a virtual environment:
   ```bat
   py -m venv .venv
   .venv\Scripts\activate
   ```
5. Install dependency:
   ```bat
   python -m pip install -r requirements.txt
   ```
6. Start the app:
   ```bat
   python app.py
   ```
7. Open http://127.0.0.1:5000 in your browser and create an account.

## macOS / Linux
```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python app.py
```

## Database
The first run creates `friendsph.db` in the project folder. Keep this file safe; it contains account and social data. To back up, stop the app and copy this file.

## Important before public launch
This is a functional local starter, not yet production-hardened. Before deploying to the public internet:
- Set a long, random `FRIENDSPH_SECRET` environment variable.
- Turn off debug mode (default is off).
- Add CSRF protection, rate limiting, email verification/password reset, account deletion, moderation/reporting, backups, HTTPS, and a production WSGI server.
- Configure secure cookies and review privacy/data-protection obligations.
- Do not use real user data until security review is complete.

The app binds to `127.0.0.1` by default and is intended for local development.
